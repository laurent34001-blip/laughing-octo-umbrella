# dealConnect
Développement d’une plateforme web permettant la mise en relation entre vendeurs et apporteurs, incluant la gestion d’annonces, des comptes utilisateurs multi-rôles, un système de commissions, et un espace public d’affichage.
